package com.example.yazan_1190145_todo1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        EditText player1Name = (EditText) findViewById(R.id.editTextt_player1Name);

        EditText player2Name = (EditText) findViewById(R.id.editTextt_player2Name);

        TextView nameErrorMsg = (TextView) findViewById(R.id.textView_nameError);

        Button startGameButton = (Button) findViewById(R.id.button_start);

        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //player name not exist
                if (player1Name.getText().toString().isEmpty() || player2Name.getText().toString().isEmpty()) {
                    nameErrorMsg.setText("Sorry,Please Enter the player names !");
                //players have the same names
                } else if ((player1Name.getText().toString()).equalsIgnoreCase(player2Name.getText().toString())) {
                    nameErrorMsg.setText("Sorry,Names must be different !");
                } else {
                    Intent intent = new Intent(MainActivity.this, GameActivity.class);
                    intent.putExtra("player1Name", player1Name.getText().toString());
                    intent.putExtra("player2Name", player2Name.getText().toString());
                    MainActivity.this.startActivity(intent);
                    finish();

                }


            }

        });


    }
}